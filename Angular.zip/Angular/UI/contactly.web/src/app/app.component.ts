import { Component, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Contacts } from '../models/contacts.model';
import { RouterOutlet } from '@angular/router';
import { AsyncPipe } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';  // Ensure HttpClientModule is imported
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, AsyncPipe, HttpClientModule,FormsModule,ReactiveFormsModule],  // Add HttpClientModule here
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  http = inject(HttpClient);
  contactsForm=new FormGroup({
    name:new FormControl<string>(''),
    email:new FormControl<string|null>(null),
    phone:new FormControl<string>(''),
    favorite:new FormControl<boolean>(false)
  })
  contacts$= this.getContacts();

  onFormSubmit(){
    // console.log(this.contactsForm.value);
    const addContactRequests={
      name:this.contactsForm.value.name,
      email:this.contactsForm.value.email,
      phone:this.contactsForm.value.phone,
      favorite:this.contactsForm.value.favorite
    }
    this.http.post('http://localhost:5094/api/Contacts',addContactRequests)
    .subscribe({
      next:(value)=>{
        console.log(value);
        this.contacts$=this.getContacts();
        this.contactsForm.reset();
      }
    });
  }

  onDelete(id:string){
    this.http.delete(`http://localhost:5094/api/Contacts/${id}`).subscribe({
      next:(value)=>{
        alert('Item Deleted');
        this.contacts$=this.getContacts();
      }
    })
  }

  private getContacts(): Observable<Contacts[]> {
    return this.http.get<Contacts[]>('http://localhost:5094/api/Contacts');
  }
}

