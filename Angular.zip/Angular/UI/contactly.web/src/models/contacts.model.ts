export interface Contacts{
    id:string;
    name: string;
    email:string|null;
    phone:string;
    favorite:boolean;
}