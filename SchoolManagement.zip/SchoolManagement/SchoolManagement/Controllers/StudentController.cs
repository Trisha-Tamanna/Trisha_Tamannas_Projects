﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SchoolManagement.Models;

namespace SchoolManagement.Controllers
{
    public class StudentController : Controller
    {
        private readonly AppDbContext _context;
        public StudentController(AppDbContext context)
        {
            _context = context;
        }
        public async Task<IActionResult> Index()
        {
            var students = await _context.Students
        .Include(s => s.StudentClasses)
            .ThenInclude(sc => sc.Class)
        .Include(s => s.StudentAddresses)
            .ThenInclude(sa => sa.Address)
        .ToListAsync();
            //var students = await _context.Students.ToListAsync();
            return View(students);
        }
        public IActionResult Create()
        {
            var classes = _context.Classes.ToList();
            Console.WriteLine($"Fetched {classes.Count} classes from the database.");
            ViewBag.Classes = new SelectList(classes, "ID", "Name");
            return View();
           
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Student student, int[] SelectedClasses, string[] AddressNames)
        {
            if (student == null)
            {
                return BadRequest("Student data is null.");
            }

            // Add student to the database
            _context.Add(student);
            await _context.SaveChangesAsync();

            // Add selected classes to the StudentClass table
            if (SelectedClasses != null && SelectedClasses.Any())
            {
                foreach (var classId in SelectedClasses)
                {
                    _context.Add(new StudentClass
                    {
                        StudentId = student.ID,
                        ClassId = classId
                    });
                }
                await _context.SaveChangesAsync();
            }

            // Add addresses to the StudentAddress table
            if (AddressNames != null && AddressNames.Any())
            {
                foreach (var addressName in AddressNames.Where(a => !string.IsNullOrEmpty(a)))
                {
                    var existingAddress = await _context.Addresses
                        .SingleOrDefaultAsync(a => a.Name == addressName);

                    if (existingAddress == null)
                    {
                        var newAddress = new Address
                        {
                            Name = addressName
                        };
                        _context.Add(newAddress);
                        await _context.SaveChangesAsync();
                        existingAddress = newAddress;
                    }

                    _context.Add(new StudentAddress
                    {
                        StudentId = student.ID,
                        AddressId = existingAddress.ID
                    });
                }
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }
    
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var student = await _context.Students.FindAsync(id);
            if (student == null)
            {
                return NotFound();
            }
            return View(student);
        }
        // POST: Student/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,Name,Roll")] Student student)
        {
            // Check if the provided ID matches the student ID
            if (id != student.ID)
            {
                return NotFound();
            }

            // Fetch the existing student from the database
            var existingStudent = await _context.Students.FindAsync(student.ID);
            if (existingStudent == null)
            {
                return NotFound();
            }

            try
            {
                // Update the existing student with new values
                existingStudent.Name = student.Name;
                existingStudent.Roll = student.Roll;

                // Save the changes to the database
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                // Handle concurrency exception
                if (!_context.Students.Any(e => e.ID == student.ID))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            // Redirect to the Index action method
            return RedirectToAction(nameof(Index));
        }
        private bool StudentExists(int id)
        {
            return _context.Students.Any(e => e.ID == id);
        }
        // GET: Student/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            var student = await _context.Students
        .Include(s => s.StudentClasses)
        .ThenInclude(sc => sc.Class)
        .Include(s => s.StudentAddresses)
        .ThenInclude(sa => sa.Address)
        .FirstOrDefaultAsync(s => s.ID == id);

            if (student == null)
            {
                return NotFound();
            }

            return View(student);
        }
        // GET: Student/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var student = await _context.Students
                .FirstOrDefaultAsync(m => m.ID == id);
            if (student == null)
            {
                return NotFound();
            }

            return View(student);
        }

        // POST: Student/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var student = await _context.Students.FindAsync(id);
            _context.Students.Remove(student);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

    }
}
//_context.Add(student);
//await _context.SaveChangesAsync();
//return RedirectToAction(nameof(Index));
////if (ModelState.IsValid)
////{

////}
////else
////{
////    // Log or output model state errors
////    foreach (var error in ModelState.Values.SelectMany(v => v.Errors))
////    {
////        Console.WriteLine(error.ErrorMessage);
////    }
////}
////return View(student);