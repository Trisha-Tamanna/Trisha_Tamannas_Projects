﻿namespace SchoolManagement.Models
{
    public class Class
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public ICollection<StudentClass> StudentClasses { get; set; }
    }
}
