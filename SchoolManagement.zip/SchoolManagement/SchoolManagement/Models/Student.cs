﻿using System.ComponentModel.DataAnnotations;

namespace SchoolManagement.Models
{
    public class Student
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Roll { get; set; }
        public ICollection<StudentClass> StudentClasses { get; set; }
        public ICollection<StudentAddress> StudentAddresses { get; set; }
    }
}
