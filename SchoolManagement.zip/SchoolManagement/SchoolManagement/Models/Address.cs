﻿namespace SchoolManagement.Models
{
    public class Address
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public ICollection<StudentAddress> StudentAddresses { get; set; }
    }
}
