﻿namespace SchoolManagement.Models
{
    public class StudentAddress
    {
        public int ID { get; set; }
        public int StudentId { get; set; }
        public Student Student { get; set; }
        public int AddressId { get; set; }
        public Address Address { get; set; }
    }
}
