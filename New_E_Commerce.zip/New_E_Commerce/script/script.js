//ADD Items
const btnCart = document.querySelector('.btn-cart');
const cart = document.querySelector('.cart');
const btnClose = document.querySelector('#cart-close');

btnCart?.addEventListener('click', () => {
    cart?.classList.add('cart-active');
});

btnClose?.addEventListener('click', () => {
    cart?.classList.remove('cart-active');
});
document.addEventListener('DOMContentLoaded', loadfood);

function loadfood() {
    loadCartFromLocalStorage();
    loadContest();
}

function loadContest() {
    let btnRemove = document.querySelectorAll('.cart-remove');
    btnRemove.forEach((btn) => {
        btn.addEventListener('click', removeItem);
    });

    let qtyElement = document.querySelectorAll('.cart-quantity');
    qtyElement.forEach((input) => {
        input.addEventListener('change', changeQty);
    });

    let cartItems = document.querySelectorAll('.add-cart');
    cartItems.forEach((btn) => {
        btn.addEventListener('click', addCart);
    });
    updateTotal();
    updateCartCount();
}

function removeItem() {
    if (confirm('Are you sure to remove?')) {
        let title = this.parentElement.querySelector('.cart-food-title').innerHTML;
        itemList = itemList.filter(el => el.title != title);
        this.parentElement.remove();
        saveCartToLocalStorage();
        loadContest();
    }
}

function changeQty() {
    if (isNaN(this.value) || this.value < 1) {
        this.value = 1;
    }
    saveCartToLocalStorage();
    loadContest();
}

let itemList = [];

function addCart() {
    let food = this.parentElement;
    let title = food.querySelector('.food-title').innerHTML;
    let price = food.querySelector('.food-price').innerHTML;
    let imgSrc = this.parentElement.querySelector('.food-img').src;

    let newProduct = { title, price, imgSrc };

    if (itemList.find((el) => el.title == newProduct.title)) {
        alert("Product already added in cart");
        return;
    } else {
        itemList.push(newProduct);
    }
    let newProducElement = createCartProduct(title, price, imgSrc);
    let element = document.createElement('div');
    element.innerHTML = newProducElement;
    let cartBasket = document.querySelector('.cart-content');
    cartBasket.append(element);
    saveCartToLocalStorage();
    loadContest();
}

function createCartProduct(title, price, imgSrc) {
    return `<div class="cart-box">
                <img src="${imgSrc}" class="cart-img">
                <div class="detail-box">
                    <div class="cart-food-title">${title}</div>
                    <div class="price-box">
                        <div class="cart-price">${price}</div>
                        <div class="cart-amt">${price}</div>
                    </div>
                    <input type="number" value="1" class="cart-quantity">
                </div>
                <i class="fa fa-trash cart-remove"></i>
            </div>`;
}

function updateTotal() {
    const cartItems = document.querySelectorAll('.cart-box');
    const totalValue = document.querySelector('.total-price');

    let total = 0;
    cartItems.forEach(product => {
        let priceElement = product.querySelector('.cart-price');
        let price = parseFloat(priceElement.innerHTML.replace("tk", ""));
        let qty = product.querySelector('.cart-quantity').value;
        total += (price * qty);
        product.querySelector('.cart-amt').innerHTML = "tk" + (price * qty);
    });
    totalValue.innerHTML = 'tk.' + total;
}

function saveCartToLocalStorage() {
    localStorage.setItem('cartItems', JSON.stringify(itemList));
}

function loadCartFromLocalStorage() {
    const storedItems = localStorage.getItem('cartItems');
    if (storedItems) {
        itemList = JSON.parse(storedItems);
        let cartBasket = document.querySelector('.cart-content');
        cartBasket.innerHTML = '';
        itemList.forEach(item => {
            let newProducElement = createCartProduct(item.title, item.price, item.imgSrc);
            let element = document.createElement('div');
            element.innerHTML = newProducElement;
            cartBasket.append(element);
        });
        loadContest();
    }
}

// Update cart count
function updateCartCount() {
    const cartCount = document.querySelector('.cart-count');
    let count = itemList.length;
    cartCount.innerHTML = count;

    if (count == 0) {
        cartCount.style.display = 'none';
    } else {
        cartCount.style.display = 'block';
    }
}

document.addEventListener('DOMContentLoaded', () => {
    loadfood();
    updateCartCount();
});

// document.addEventListener('DOMContentLoaded', loadfood);

// function loadfood() {
//     loadContest();
// }

// function loadContest() {
//     let btnRemove = document.querySelectorAll('.cart-remove');
//     console.log(btnRemove);
//     btnRemove.forEach((btn) => {
//         btn.addEventListener('click', removeItem);
//     });

//     let qtyElement = document.querySelectorAll('.cart-quantity');
//     qtyElement.forEach((input) => {
//         input.addEventListener('change', changeQty);
//     });

//     let cartItems = document.querySelectorAll('.add-cart');
//     cartItems.forEach((btn) => {
//         btn.addEventListener('click', addCart);
//     });
//     updateTotal();
// }

// function removeItem() {
//     if (confirm('Are you sure to remove?')) {
//         let title = this.parentElement.querySelector('.cart-food-title').innerHTML;
//         itemList = itemList.filter(el => el.title != title);
//         this.parentElement.remove();
//         loadContest();
//     }
// }

// function changeQty() {
//     if (isNaN(this.value) || this.value < 1) {
//         this.value = 1;
//     }
//     loadContest();
// }

// let itemList = [];

// function addCart() {
//     let food = this.parentElement;
//     let title = food.querySelector('.food-title').innerHTML;
//     let price = food.querySelector('.food-price').innerHTML;
//     let imgSrc = this.parentElement.querySelector('.food-img').src;

//     let newProduct = { title, price, imgSrc };

//     if (itemList.find((el) => el.title == newProduct.title)) {
//         alert("Product already added in cart");
//         return;
//     } else {
//         itemList.push(newProduct);
//     }
//     let newProducElement = createCartProduct(title, price, imgSrc);
//     let element = document.createElement('div');
//     element.innerHTML = newProducElement;
//     let cartBasket = document.querySelector('.cart-content');
//     cartBasket.append(element);
//     loadContest();
// }

// function createCartProduct(title, price, imgSrc) {
//     return `<div class="cart-box">
//                 <img src="${imgSrc}" class="cart-img">
//                 <div class="detail-box">
//                     <div class="cart-food-title">${title}</div>
//                     <div class="price-box">
//                         <div class="cart-price">${price}</div>
//                         <div class="cart-amt">${price}</div>
//                     </div>
//                     <input type="number" value="1" class="cart-quantity">
//                 </div>
//                 <i class="fa fa-trash cart-remove"></i>
//             </div>`;
// }

// function updateTotal() {
//     const cartItems = document.querySelectorAll('.cart-box');
//     const totalValue = document.querySelector('.total-price');

//     let total = 0;
//     cartItems.forEach(product => {
//         let priceElement = product.querySelector('.cart-price');
//         let price = parseFloat(priceElement.innerHTML.replace("tk", ""));
//         let qty = product.querySelector('.cart-quantity').value;
//         total += (price * qty);
//         product.querySelector('.cart-amt').innerHTML = "tk" + (price * qty);
//     });
//     totalValue.innerHTML = 'tk.' + total;
// }

// const cartCount = document.querySelector('.cart-count');
// let count = itemList.length;
// cartCount.innerHTML = count;

// if (count == 0) {
//     cartCount.style.display = 'none';
// } else {
//     cartCount.style.display = 'block';
// }